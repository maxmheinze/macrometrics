#Garbage

as.Date(paste(euromomo_z_score$week, "1", sep = "-"), format = "%Y-%W-%D") # 1st day (Year Weak Day)
as.Date(paste("2", euromomo_z_score$week, sep = "."), format = "%w.%W.%Y") # 2nd day (Tuesday 01 nov 2016)
# new format 
format(as.Date(paste("1", date_week, sep = "."), format = "%Y.%W.%D"), "%Y-%m")
# [1] "2016-10"
format(as.Date(paste("2", date_week, sep = "."), format = "%w.%W.%Y"), "%Y-%m")
# [1] "2016-11"






# Assuming df2 is the dataframe with year and month in separate columns
# For df2, we'll create a new column "Date" that represents the first day of each month
hepi_ppi_2$Year <- as.integer(hepi_ppi_2$year)

month.name <- c("Jan", "Feb", "Mar", "Apr", "May", "June", "July", "Aug", "Sep", "Oct", "Nov", "Dec")

hepi_ppi_2$Month <- match(tolower(hepi_ppi_2$month), tolower(month.name))

hepi_ppi_2$Date <- as.Date(paste(hepi_ppi_2$Year, hepi_ppi_2$Month, "01", sep="-"), "%Y-%m-%d")

hepi_ppi_2$Date <- 
  
  # Now you can merge the two data frames by the "Date" column
  df3 <- left_join(euromomo_score, hepi_ppi_2 %>% select(country, Date, elect_ppi, gas_ppi), by = c("Year", "country"))

view(df3)








# Load necessary libraries
library(lubridate)
library(stringr)

# Read in the csv file
euromomo_z_score <- read_delim("charts-z-scores-by-country (2).csv", delim = ";", escape_double = FALSE, trim_ws = TRUE, show_col_types = FALSE)

# Extract year and week separately from week column
euromomo_score <- euromomo_z_score %>%
  mutate(year = as.numeric(substr(week, 1, 4))) %>%
  mutate(week_sep = as.numeric(substr(week, 6, 7))) 

# Split the week column to get Year and Week separately
euromomo_score$Year <- as.integer(str_split_fixed(euromomo_score$week, "-", 2)[,1])
euromomo_score$Week <- as.integer(str_split_fixed(euromomo_score$week, "-", 2)[,2])

# Correct for the year of week 53
last_day_of_year <- ymd(paste(euromomo_score$Year, "12-31", sep="-"))
should_be_53 <- wday(last_day_of_year) %in% c(5, 6, 7)  # Thursday, Friday, Saturday
euromomo_score$Year[euromomo_score$Week == 53 & !should_be_53] <- euromomo_score$Year[euromomo_score$Week == 53 & !should_be_53] + 1
euromomo_score$Week[euromomo_score$Week == 53 & !should_be_53] <- 1

# Create date from year, week and a fixed weekday
euromomo_score$Date <- as.Date(paste(euromomo_score$Year, euromomo_score$Week, 1, sep="-"), "%Y-%U-%u")

# Replace NA values in the Date column with a specified date
replacement_date <- as.Date("2020-12-31")
euromomo_score$Date[is.na(euromomo_score$Date)] <- replacement_date

# Add month column
euromomo_score$month <- month(euromomo_score$Date)

# Convert month names to numeric values in hepi_ppi_3 data frame
month.name <- c("Jan", "Feb", "Mar", "Apr","May",  "June", "July", "Aug","Sep", "Oct", "Nov", "Dec")
hepi_ppi_3$month <- match(tolower(hepi_ppi_3$month), tolower(month.name))

# Clean country names
euromomo_score_clean <- euromomo_score %>%
  mutate(country_clean = case_when(
    country == "Germany (Hesse)" ~ "Germany",
    country == "Germany (Berlin)" ~ "Germany",
    TRUE ~ country  # keep original value for other cases
  ))

euromomo_score_clean_1 <- euromomo_score_clean %>%
  mutate(country_clean = case_when(
    country_clean == "UK (England)" ~ "United Kingdom",
    country_clean == "UK (Scotland)" ~ "United Kingdom",
    country_clean == "UK (Wales)" ~ "United Kingdom",
    TRUE ~ country_clean  # keep original value for other cases
  ))

# Join euromomo_score_clean_1 and hepi_ppi_3 data frames
df3 <- left_join(euromomo_score_clean_1 %>% select(country,country_clean, year, month, week_sep, zscore), 
                 hepi_ppi_3 %>% select(country_clean, year, month, elect_ppi, gas_ppi), 
                 by = c("country_clean", "year", "month"))

# Select required columns
eurmomo_z_gasppi_electppi_1 <- df3 %>% select(country, year, month, week_sep, zscore, elect_ppi, gas_ppi)

# Create a new column "period"
eurmomo_z_gasppi_electppi <- eurmomo_z_gasppi_electppi_1 %>%
  mutate(period = as.integer(paste(year, month, week_sep, sep ="")))

