#Analysis
library(fixest)

cor.test(eurmomo_z_gasppi_electppi$zscore, log(eurmomo_z_gasppi_electppi$gas_ppi))
cor.test(eurmomo_z_gasppi_electppi$zscore, log(eurmomo_z_gasppi_electppi$elect_ppi))

cor.test(eurmomo_z_gasppi_electppi$elect_ppi, log(eurmomo_z_gasppi_electppi$gas_ppi))

var(log(na.omit(eurmomo_z_gasppi_electppi$elect_ppi)))
var(log(na.omit(eurmomo_z_gasppi_electppi$gas_ppi)))

lm(data = eurmomo_z_gasppi_electppi)

est_panel = feols(zscore ~  log(gas_ppi) | country + period, data = eurmomo_z_gasppi_electppi %>%
                    filter(month %in% c(11, 12, 1, 2)))

est_panel = feols(zscore ~  log(gas_ppi) | country + period, data = eurmomo_z_gasppi_electppi %>%
                    filter(year %in% c(2022, 2023)) %>%
                    filter(month %in% c(11, 12, 1, 2)))

summary(est_panel)
pdat = panel(eurmomo_z_gasppi_electppi, ~country + period)

est_panel = feols(zscore ~  log(gas_ppi) | country + period, data = pdat %>%
                    filter(month %in% c(11, 12, 1, 2)))
summary(est_panel)
